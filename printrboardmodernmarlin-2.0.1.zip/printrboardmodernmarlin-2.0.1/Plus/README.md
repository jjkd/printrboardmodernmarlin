<h1>Printrbot Plus</h1>
<p>This was created using the current Play V2 HDB (heated bed) firmware but with the dimensions set to 253x253x253. It has not been tested so be watching it when you run G28/G29 the first time.</p>
